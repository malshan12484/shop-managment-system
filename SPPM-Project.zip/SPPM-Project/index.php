<?php 
ob_start();
require('config.php');
session_start();
if(!isset($_SESSION["username"])){
	header('Location:content/login/Login.php');
}



?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Sithara Textile- Dashboard</title>

    <!-- Custom fonts for this template-->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="css/sb-admin-2.min.css" rel="stylesheet">
	
	
	<link href="https://cdn.jsdelivr.net/gh/bbbootstrap/libraries@main/datedropper.css" rel="stylesheet">
	<script src="https://cdn.jsdelivr.net/gh/bbbootstrap/libraries@main/datedropper.js"></script>
	
	
	

</head>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
        <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

            <!-- Sidebar - Brand -->
            <a class="sidebar-brand d-flex align-items-center justify-content-center" href="index.html">
                <div class="sidebar-brand-icon rotate-n-15">
                    <i class="fas fa-id-badge" aria-hidden="true"></i>
                </div>
                <div class="sidebar-brand-text mx-3">Sithara Textiles</div>
            </a>

            <!-- Divider -->
            <hr class="sidebar-divider my-0">

            <!-- Nav Item - Dashboard -->
            <li class="nav-item active">
                <a class="nav-link" href="index.php">
                    <i class="fas fa-solid fa-chart-line"></i>
                    <span>Dashboard</span></a>
            </li>

            <!-- Divider -->
            <!-- <hr class="sidebar-divider"> -->

            <!-- Heading -->
            <!-- <div class="sidebar-heading">
                Interface
            </div> -->

           
            <li class="nav-item">
                <a class="nav-link" href="attendance.php">
                    <i class="fas fa-fw fa-table"></i>
                    <span>Attendance</span></a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="verify.php">
                    <i class="fas fa-fw fa-table"></i>
                    <span>Verify Employees</span></a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="content/FaceRecognizer/activate.php">
                    <i class="fas fa-fw fa-table"></i>
                    <span>Activate Employees</span></a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="content/FaceRecognizer/clockin.php">
                    <i class="fas fa-fw fa-table"></i>
                    <span>Clock-In</span></a>
            </li>
            
             
            <!-- <li class="nav-item">
                <a class="nav-link" href="tables.html">
                    <i class="fas fa-fw fa-table"></i>
                    <span>Attendance</span></a>
            </li> -->

            <!-- Divider -->
            <hr class="sidebar-divider d-none d-md-block">

            <!-- Sidebar Toggler (Sidebar) -->
            <div class="text-center d-none d-md-inline">
                <button class="rounded-circle border-0" id="sidebarToggle"></button>
            </div>

           

        </ul>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">

                    <!-- Sidebar Toggle (Topbar) -->
                    <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
                        <i class="fa fa-bars"></i>
                    </button>


                    <!-- Topbar Navbar -->
                    <ul class="navbar-nav ml-auto">

                        <!-- Nav Item - Search Dropdown (Visible Only XS) -->
                       
                            
                            <!-- Dropdown - Messages -->
                            <div class="dropdown-menu dropdown-menu-right p-3 shadow animated--grow-in"
                                aria-labelledby="searchDropdown">
                                <form class="form-inline mr-auto w-100 navbar-search">
                                    <div class="input-group">
                                        <input type="text" class="form-control bg-light border-0 small"
                                            placeholder="Search for..." aria-label="Search"
                                            aria-describedby="basic-addon2">
                                        <div class="input-group-append">
                                            <button class="btn btn-primary" type="button">
                                                <i class="fas fa-search fa-sm"></i>
                                            </button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </li>

                        <!-- Nav Item - Alerts -->
                       

                        <div class="topbar-divider d-none d-sm-block"></div>

                        <!-- Nav Item - User Information -->
                       
                            <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <span class="d-none d-lg-inline"><h6>Welcome ! <span><?php 
                                   $session=$_SESSION["username"];
                                   echo " ".$session;
                                   

                                        ?></h6></span>
                                       
                               
                            </a>
                            <li class="nav-item dropdown no-arrow logout-section">
                               <a class="text-decoration-none" href="logout.php"><i class="fas fa-sign-out-alt fa-sm fa-fw mt-3 text-gray-400"></i>&nbsp;Logout</a>
                            </li>
                            
                            </div>
                        </li>

                    </ul>

                </nav>
                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <div class="d-sm-flex align-items-center justify-content-between mb-4">
						
                        <h1 class="h3 mb-0 text-dark">Dashboard</h1>
						
                    </div>
					
					
					 <div class="row justify-content-center">
					 
					 				 
						<div class="col-xl-3 col-md-6 mb-4">
                            <div class="card border-left-success shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
									<div class="col-auto">
                                            <i class="fas fa-solid fa-user-check"></i>
                                        </div>
                                        <div class="col mr-2">
                                            <div class="text-m font-weight-bold text-success text-uppercase mb-1" align="center">
                                                Active Employees</div>
                                            <div class="h4 mb-0 font-weight-bold text-gray-800" align="center">
                                            <?php
                                                $con = mysqli_connect("localhost", "root", "", "sppm");


	                                           if (mysqli_connect_errno()) {
		                                              echo "Database connection failed.";
	                                                                       }

	                                           $query = "SELECT * FROM `attendance` WHERE `status`='active';";


	                                           $result = mysqli_query($con, $query);

	                                           if ($result) {

		                                      $row = mysqli_num_rows($result);
		                                      if ($row) {
			 	                              printf(" " . $row);
			                                             }

		                                      mysqli_free_result($result);
	                                                       }


                                            ?>
                                            </div>
                                        </div>
                                        
                                    </div>
                                </div>
                            </div>
                        </div>
                  
                        <div class="col-xl-3 col-md-6 mb-4">
                            <div class="card border-left-primary shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col-auto">
                                          <i class='fa fa-users'></i>
                                        </div>
										<div class="col mr-2">
                                            <div class="text-m font-weight-bold text-primary text-uppercase mb-1" align="center">
                                                Total Employees</div>
                                            <div class="h4 mb-0 font-weight-bold text-gray-800" align="center">
                                            <?php
                                                $con = mysqli_connect("localhost", "root", "", "sppm"); 
	
	
	                                           if (mysqli_connect_errno()) { 
		                                              echo "Database connection failed."; 
	                                                                       } 
	
	                                           $query = "SELECT * FROM `profile`";
	
	
	                                           $result = mysqli_query($con, $query); 
	
	                                           if ($result) { 
		 
		                                      $row = mysqli_num_rows($result); 
		                                      if ($row) { 
			 	                              printf(" " . $row); 
			                                             } 
		
		                                      mysqli_free_result($result); 
	                                                       } 


                                            ?> 
                                            </div>
                                        </div>
                                        
                                        
                                    </div>
                                </div>
                            </div>
                        </div>
						
						
						</div>

					
					
					<div class="row">

                        <div class="col-xl-4 col-lg-7 mb-4">
							<!-- Active Employees -->
							<div class="card shadow mb-4">
										<!-- Card Header - Dropdown -->
										<div class="card-header py-3">
											<h4 class="m-0 font-weight-bold text-primary" align="center">Active Employees</h4>
										</div>
										<!-- Card Body -->
										<div class="card-body">
											<div class="chart-pie ">
												<canvas id="myPieChart"></canvas>
												
											</div>
											<hr>
											<h1 align="center">66%</h1>
											
										</div>
									</div>
					</div>
							
							
						 <div class="col-xl-8 col-lg-7">
							<!--Daily records-->
							<div class="card shadow mb-4 ">
										<div class="card-header py-3">
											<h4 class="m-0 font-weight-bold text-primary" align="center">Monthly Progress</h4>
										</div>
										<div class="card-body">
											<div class="chart-area">
												<canvas id="myAreaChart"></canvas>
											</div>
											<hr>
											
										</div>
							</div>
						</div>
					</div>
					
					 <div class="row">
                                <div class="col-lg-12 mb-4">
                                    <div class="card bg-primary text-white shadow">
                                        <div class="card-body">
                                            <h5 align="center">Monthly Report - All Employees</h5>
											<hr>
                                            <div class="container mt-100">
												
													<div class="row">
														<div class="col-md-4"> <label>From</label> <input type="text" class="form-control"> </div>
														<div class="col-md-4"> <label>To</label> <input type="text" class="form-control"> </div>
														<div class="col-md-4"> <label>Search</label> <button class="btn btn-success pro-button w-100">Generate Report<i class="fas fa-download fa-sm text-white-50"></i></button> </div>
													</div>
												
											</div>
                                        </div>
                                    </div>
                                </div>
                        </div>
						
						 <div class="row">
                                <div class="col-lg-12 mb-4">
                                    <div class="card bg-primary text-white shadow">
                                        <div class="card-body">
                                            <h5 align="center">Monthly Report - Individual Employee</h5>
											<hr>
                                            <div class="container mt-200">
												
													<div class="row">
														<div class="col-md-4"> <label>From</label> <input type="text" class="form-control"> </div>
														<div class="col-md-4"> <label>To</label> <input type="text" class="form-control"> </div>
														<div class="col-md-2"> <label></label> 
															<div class="dropdown mt-2">
																<button class="btn btn-primary dropdown-toggle" type="button"
																	id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true"
																	aria-expanded="false">
																	Select Employee
																</button>
																<div class="dropdown-menu animated--fade-in"
																	aria-labelledby="dropdownMenuButton">
																	<a class="dropdown-item" href="#">Action</a>
																	<a class="dropdown-item" href="#">Another action</a>
																	<a class="dropdown-item" href="#">Something else here</a>
																</div>
															</div>
															
														</div>
														<div class="col-md-2 mt-2">
														<label></label>
															<button class="btn btn-success pro-button w-100">Generate Report<i class="fas fa-download fa-sm text-white-50"></i></button> 
														</div>
												</div>
												
											</div>
                                        </div>
                                    </div>
                                </div>
                        </div>
					
					
			
                           
					
																			
					
					<!-- Content Row -->
                    
            <!-- Footer -->
            <footer class="sticky-footer bg-white">
                <div class="container my-auto">
                    <div class="copyright text-center my-auto">
                        <span>Copyright &copy; Sithara Textiles</span>
                    </div>
                </div>
            </footer>
            <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->

    </div>
	
	<script>
	$(document).ready(function(){
		$('input').dateDropper({
					});
	});
		
	</script>
    
    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin-2.min.js"></script>

    <!-- Page level plugins -->
    <script src="vendor/chart.js/Chart.min.js"></script>

    <!-- Page level custom scripts -->
    <script src="js/demo/chart-area-demo.js"></script>
    <script src="js/demo/chart-pie-demo.js"></script>
	
	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css"></script>
	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.bundle.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"></script>
	
	
	
	
	
</script>
	
</body>

</html>