<?php
ob_start(); 
session_start();
unset($_SESSION["id"]);
header('Location:content/login/Login.php');
ob_end_flush();

?>