<?php 
ob_start();
require('config.php');
session_start();
if(!isset($_SESSION["username"])){
	header('Location:content/login/Login.php');
}



?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Sithara Textile- Dashboard</title>

    <!-- Custom fonts for this template-->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="css/sb-admin-2.min.css" rel="stylesheet">
	
	
	<link href="https://cdn.jsdelivr.net/gh/bbbootstrap/libraries@main/datedropper.css" rel="stylesheet">
	<script src="https://cdn.jsdelivr.net/gh/bbbootstrap/libraries@main/datedropper.js"></script>
	
	
	

</head>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
        <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

            <!-- Sidebar - Brand -->
            <a class="sidebar-brand d-flex align-items-center justify-content-center" href="index.html">
                <div class="sidebar-brand-icon rotate-n-15">
                    <i class="fas fa-id-badge" aria-hidden="true"></i>
                </div>
                <div class="sidebar-brand-text mx-3">Sithara Textiles</div>
            </a>

            <!-- Divider -->
            <hr class="sidebar-divider my-0">

            <!-- Nav Item - Dashboard -->
            
            <!-- Divider -->
            <!-- <hr class="sidebar-divider"> -->

            <!-- Heading -->
            <!-- <div class="sidebar-heading">
                Interface
            </div> -->

           
            <li class="nav-item active">
                <a class="nav-link" href="index.php">
                    <i class="fas fa-solid fa-chart-line"></i>
                    <span>Dashboard</span></a>
            </li>

            <!-- Divider -->
            <!-- <hr class="sidebar-divider"> -->

            <!-- Heading -->
            <!-- <div class="sidebar-heading">
                Interface
            </div> -->

           
            <li class="nav-item">
                <a class="nav-link" href="attendance.php">
                    <i class="fas fa-fw fa-table"></i>
                    <span>Attendance</span></a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="verify.php">
                    <i class="fas fa-fw fa-table"></i>
                    <span>Verify Employees</span></a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="content/FaceRecognizer/activate.php">
                    <i class="fas fa-fw fa-table"></i>
                    <span>Activate Employees</span></a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="content/FaceRecognizer/clockin.php">
                    <i class="fas fa-fw fa-table"></i>
                    <span>Clock-In</span></a>
            </li>
             
            <!-- <li class="nav-item">
                <a class="nav-link" href="tables.html">
                    <i class="fas fa-fw fa-table"></i>
                    <span>Attendance</span></a>
            </li> -->

            <!-- Divider -->
            <hr class="sidebar-divider d-none d-md-block">

            <!-- Sidebar Toggler (Sidebar) -->
            <div class="text-center d-none d-md-inline">
                <button class="rounded-circle border-0" id="sidebarToggle"></button>
            </div>

           

        </ul>

        <!-- Page Content  -->
        
        
        <div id="content">
            <nav class="navbar navbar-light navbar-expand bg-white shadow mb-4 topbar static-top">
                <div class="container-fluid">

                <div class="topbar-divider d-none d-sm-block"></div>

<!-- Nav Item - User Information -->
<li class="nav-item dropdown no-arrow">
    <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button"
        data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
        <span class="d-none d-lg-inline"><h6>Welcome ! <span><?php 
           $session=$_SESSION["username"];
           echo " ".$session;
           

                ?></h6></span>
               
        <!-- <img class="img-profile rounded-circle"
            src="img/undraw_profile.svg"> -->
    </a>
    <li class="nav-item dropdown no-arrow logout-section">
       <a class="text-decoration-none" href="logout.php"><i class="fas fa-sign-out-alt fa-sm fa-fw mt-3 text-gray-400"></i>&nbsp;Logout</a>
    </li>
             
                    
                </div>
            </nav>
             <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-6 col-xl-6 mt-3">
                            <div class="col">
                                    <div class="card shadow mb-3">
                                        <div class="card-header py-3">
                                            <p class="text-danger m-0 font-weight-bold">Generate Code</p>
                                        </div>
                                        <div class="card-body">
                                            <form class="employee" method="post" action="verify.php">
                                                <div class="form-row">
                                                    <div class="col">
                                                        <div class="form-group"><label for="full_name"><strong>Emp. ID</strong></label><input class="form-control" type="text" id="e-id" placeholder="Employee ID" name="e-id"></div>
                                                    </div>
                                                    
                                                </div>
                                                <div class="form-group"><button class="btn btn-outline-success btn-sm" name="btn-submit"type="submit">Generate Code</button></div>
                                            </form>
                                            <?php
                                                 if(isset($_POST["btn-submit"])){
                                                      $id=$_POST["e-id"];
                                                      $random=rand(1000,9999);
                                                     /*$sql="INSERT INTO `verify` (`empid`, `code`,`status`) VALUES ('".$id."', '".$random."','Inactive');";*/
                                                     $sql="UPDATE `profile` SET `tempPass`='$random' WHERE `empid`='$id'";
                                                     $result=mysqli_query($conn,$sql);
                                                     header('Location:verify.php');
                                                 
                                                 
                                                 }
                                            
                                            ?>
                                        </div>
                                    </div>
                                    
                                </div> 
                        </div>
                           <div class="col-lg-6 col-xl-6 mt-3">
                            <div class="card shadow">
                        <div class="card-header py-3">
                            <p class="text-danger m-0  font-weight-bold">Temporary Passcode</p>
                        </div>
                        <div class="card-body">
                            <div style="height:300px; overflow-y:auto;" class="table-responsive table mt-2" id="dataTable" role="grid" aria-describedby="dataTable_info">
                                <table class="table my-0" id="dataTable">
                                    <thead>
                                        <tr>
                                            <th>Emp. ID</th>
                                            <th>Name</th>
                                            <th>Temp. Password</th>
                                            <th>Status</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                         <?php
//this one edited
$sql='SELECT * FROM profile';
$result = mysqli_query($conn, $sql);
$number_of_results = mysqli_num_rows($result);


?>
                                     
                                         <?php
                                           
                                                //output data of each row
                                                while($row = mysqli_fetch_array($result))  {
                                        ?>

					<tr>
                    <td><?php echo $row['empid']; ?></td>
                    <td><?php echo $row['fullname']; ?></td>
					<td><?php echo $row['tempPass']; ?></td>
					<td><?php echo $row['status']; ?></td>
                   
                    
                        
					
					</tr>	
        
           <?php		
			}
		?>
                                        
		
                                    </tbody>
                                </table>
                            </div>
                          
                        </div>
                    </div>   
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-6 mb-4">
                           
                            
                        </div>
                        <div class="col">
                            <div class="row">
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
  
     <!-- jQuery CDN - Slim version (=without AJAX) -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <!-- Popper.JS -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.0/umd/popper.min.js" integrity="sha384-cs/chFZiN24E4KMATLdqdvsezGxaGsi4hLGOzlXwp5UZB1LY//20VyM2taTB4QvJ" crossorigin="anonymous"></script>
    <!-- Bootstrap JS -->
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/js/bootstrap.min.js" integrity="sha384-uefMccjFJAIv6A+rW+L4AHf99KvxDjWSu1z9VI8SKNVmz4sk7buKt/6v9KI65qnm" crossorigin="anonymous"></script>

    <script type="text/javascript">
        $(document).ready(function () {
            $('#sidebarCollapse').on('click', function () {
                $('#sidebar').toggleClass('active');
            });
        });
    </script>
    </body>
</html>
