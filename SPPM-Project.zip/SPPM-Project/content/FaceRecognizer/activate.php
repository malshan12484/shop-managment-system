<?php
ob_start();
require('config.php');
if(isset($_POST['btn-submit'])){
        $passcode=$_POST['code'];
         $sql= "SELECT `tempPass` FROM `profile` WHERE `tempPass`='".$passcode."';";
        $result = mysqli_query($conn,$sql);
        if(mysqli_num_rows($result)>0){
            $sql= "SELECT `empid` FROM `profile` WHERE `tempPass`='".$passcode."';";
            $sqlUp="UPDATE `profile` SET `status`='Activated' WHERE `tempPass`='$passcode'";
            $resultup = mysqli_query($conn,$sqlUp);
            $result = mysqli_query($conn,$sql);
            while($row = mysqli_fetch_array($result))  {
                $cookieValue=$row['empid'];
               setcookie("user",$cookieValue,time()+31556926, "/");
                header('Location:clockIn.php');


            }


        }else{
              echo'<div class="alert alert-danger mt-2" role="alert">Passcode is incorrect</div>';
                                            }
                                            
                                             
                                        }
                                    
                                    ob_end_flush();

            ?>
                                                
<!DOCTYPE html>
<html>

<head>
     <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>Login - Brand</title>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/css/bootstrap.min.css" integrity="sha384-9gVQ4dYFwwWSjIDZnLEWnxCjeSWFphJiwGPXr1jddIhOegiu1FwO5qRGvFXOdJZ4" crossorigin="anonymous">
     <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>Login - Brand</title>
    <link rel="stylesheet" href="Resources/CSS/bootstrap.min.css">
    
</head>

<body style="background-color:blue;">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-xl-6">
                <div class="card shadow-lg o-hidden border-0 my-5">
                    <div class="card-body p-0">
                        <div class="row">
                            <div class="col -lg-5">
                                
                                <div class="px-5 pb-5 pt-4">
                                    <div class="text-center">
                                        <h4 class="text-dark mb-4 font-bold">ACTIVATE EMPLOYEE</h4><hr>
                                    </div>
                                    <form class="user" action="activate.php" method="post">
                                        <div class="form-group"><input name="code" id="code" class="form-control form-control-user" type="text" id="exampleInputEmail" aria-describedby="emailHelp" placeholder="Enter Passcode" name="code"></div>
                                        <button onclick="getdetails()" name="btn-submit" id="btn-submit"style="border-radius:20px;background:blue; color:#fff" class="btn btn-block text-white btn-user" type="submit">Activate</button>
                                        
                                        <hr>
                                        
                                    </form>
                                    
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
   
                
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
    <script src="assets/js/chart.min.js"></script>
    <script src="assets/js/bs-init.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.4.1/jquery.easing.js"></script>
    <script src="assets/js/theme.js"></script>
</body>

</html>