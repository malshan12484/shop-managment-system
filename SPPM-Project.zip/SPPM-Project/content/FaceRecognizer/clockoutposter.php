<!DOCTYPE html>
<html>
    <head>
        <title>Create Admin</title>
        <link rel="stylesheet" type="text/css" href="posters-style.css">
        <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Lato:wght@100;400&display=swap" rel="stylesheet">
        <script src="https://code.jquery.com/jquery-3.6.0.js" integrity="sha256-H+K7U5CnXl1h5ywQfKtSj8PCmoN9aaq30gDh27Xc0jk=" crossorigin="anonymous"></script>
    </head>
    <body>
        <div class="main-frame poster-1-mainframe">
            <div class="main-frame-3">
                <div class="container-fluid poster-1">
                    <img width=100% src="check.png">
                    <h1>CLOCKED OUT</h1>
                </div>

            </div>
            <script>
            setTimeout(function(){
                     window.location.href = 'clockIn.php';
                            },800);
             </script>
        </div>
    </body>
</html>
