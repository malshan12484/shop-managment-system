<?php
ob_start();
if(isset($_COOKIE["user"])){
  $empid=$_COOKIE["user"];

}



?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Document</title>

  <script defer src="face-api.min.js"></script>
  <script defer src="script.js"></script>
  <style>
    body {
      margin: 0;
      padding: 0;
      width: 100vw;
      height: 100vh;
      display: flex;
      justify-content: center;
      align-items: center;
      background: #5687ee;
    }

    canvas {
      position: absolute;
    }

    video {
      border-radius: 50%;
      box-shadow: 0 0 100px -50px #000;
    }
  </style>
</head>

<body>
  
  <div class="video-main">
  <form class="user" action="clock-backend.php" method="post">
    <video id="video" width="500"  height="400" autoplay muted></video>
    <br>
    <br>
    <br>
    <div class="form-group"><input readonly name="id" id="id" class="form-control form-control-user" type="text" id="exampleInputEmail" aria-describedby="emailHelp" placeholder="Enter Employee ID" name="username"></div>
    <input class="date" type="hidden" name="date" id="date">
    <input class="time" type="hidden" name="time" id="time">
    <button onclick="getdetails()" name="btn-submit" id="btn-submit" class="btn btn-block text-white btn-user" style="border-radius:50px;text-align:center;background:white; color:black" type="submit">Clock In / Clock Out</button>
   
  </form>
  </div>
 
       <script>
                    function getdetails(){
                        var today=new Date();
                        var date=today.getFullYear()+"-"+("0" + (today.getMonth() + 1)).slice(-2)+"-"+("0" +today.getDate()).slice(-2);
                        var time=today.getHours()+":"+today.getMinutes();
                        document.getElementById("date").value=date;
                        document.getElementById("time").value=formatAMPM(new Date);
                        
                    }
                    
                    function formatAMPM(date) 
                    {
                      var hours = date.getHours();
                      var minutes = date.getMinutes();
                      var ampm = hours >= 12 ? 'pm' : 'am';
                      hours = hours % 12;
                      hours = hours ? hours : 12; // the hour '0' should be '12'
                      minutes = minutes < 10 ? '0'+minutes : minutes;
                      var strTime = hours + ':' + minutes + ' ' + ampm;
                      return strTime;
                    } 
                    function setempid(){
                        document.getElementById("id").value="<?php echo $empid; ?>";
                        
                    }
                   window.onload=setempid();
                
                </script>
    
  
    
</body>

</html>