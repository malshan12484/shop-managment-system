<?php
ob_start();
require('config.php');
if(isset($_POST["btn-submit"])){
    $id=$_POST["id"];
    $date=$_POST["date"];
    $time=$_POST["time"];
    $activeStatus="active";

    /*---------for the second database------------*/
    $secodTime=substr($time,0,4);

    /*-----------------------------------------------*/



    /*--------for checking the employee is real--------*/
    $sqlOne= "SELECT * FROM `profile` WHERE `empid`='".$id."';";
    /*------check the employee in clock off------------*/
    $sqlFour= "SELECT * FROM `attendance` WHERE `statusN`='".$resultFourStatus."';";
    $resultOne = mysqli_query($conn,$sqlOne);
    $resultFour = mysqli_query($conn,$sqlFour);
    /*------checking the client is real or not---------*/
    if(mysqli_num_rows($resultOne)>0){
        /*-----for checking the employee is active-----------*/
        $sqlTwo= "SELECT * FROM `attendance` WHERE `empid`='".$id."' AND `status`='".$activeStatus."';";
        $resultTwo = mysqli_query($conn,$sqlTwo);
        if(mysqli_num_rows($resultTwo)>0){
            $inactiveStatus="inactive";
            $inactive="NULL";
            $sqlThree="UPDATE `attendance` SET `status`='$inactive',`clockout`='$time',`statusN`='$inactiveStatus' WHERE `empid`='$id' AND `statusN`='$inactive'";
            $sqlAccountant="UPDATE `attendance2` SET `clockout`='$secodTime' WHERE `empid`='$id' AND `clockout`='00:00:00'";
            $resultThree = mysqli_query($conn,$sqlThree);
            $resultAccountant = mysqli_query($conn,$sqlAccountant);
            mysqli_close($conn);
            header('Location:clockoutposter.php');
        }else{
             $status="active";
            while($row=mysqli_fetch_array($resultOne)){
                $fullname=$row['fullname'];
                $sqlThree="INSERT INTO `attendance` (`adate`,`empid`,`fullname`,`clockin`,`status`,`clockout`,`statusN`) VALUES ('".$date."','".$id."','".$fullname."','".$time."','".$status."','_','NULL');";
                $sqlAccountant="INSERT INTO `attendance2` (`date`,`empid`,`clockin`,`clockout`) VALUES ('".$date."','".$id."','".$secodTime."','_');";
                $resultThree = mysqli_query($conn,$sqlThree);
                $resultAccountant = mysqli_query($conn,$sqlAccountant);
                mysqli_close($conn);
                header('Location:clockinposter.php');
                }
            }
        }
        //else{
        //     echo'<script>alert("Entered a Wrong Emplyee Number")</script>';
        //     mysqli_close($conn);
        //     header('Location:clockerror.php');
        //     }


    }
    ob_end_flush();


?>
