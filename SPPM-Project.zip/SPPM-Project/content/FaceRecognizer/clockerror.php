<!DOCTYPE html>
<html>
    <head>
        <title>Create Admin</title>
        <link rel="stylesheet" type="text/css" href="Resources/CSS/posters-style.css">
        <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Lato:wght@100;400&display=swap" rel="stylesheet"> 
        <script src="https://code.jquery.com/jquery-3.6.0.js" integrity="sha256-H+K7U5CnXl1h5ywQfKtSj8PCmoN9aaq30gDh27Xc0jk=" crossorigin="anonymous"></script>
    </head>
    <body>
        <div class="main-frame poster-1-mainframe">
            <div class="main-frame-3">
                <div class="container-fluid poster-1">
                    <img width=100% src="Resources/imgs/error.png"> 
                    <h1 style="color:#E74C3C">INCORRECT ID</h1> 
                </div>
                <div class="container-fluid">
                    <div style="text-align: center" class="link"><a style="text-decoration: none;" href="clockin.php">Go Back</a></div>    
                    
                </div>
               
            </div>
        </div>
    </body>
</html>